#!flask/bin/python
import os
import unittest

from config import basedir
from app import app, db

from app.models import User
class TestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'test.db')
        self.app = app.test_client()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()


    def test_app_exits(self):
        self.assertFalse(app is None)


    def test_check_user(self):
        """test add user"""
        u = User(username='john1', email='john@example.com', password='111111', phone='11111111111')
        db.session.add(u)
        db.session.commit()

        user = User.query.filter(User.username ==
                                 'john1').first()
        assert user is not None

    def test_add_user(self):
        """test add user"""
        u = User(username='john1', email='john@example.com', password='111111', phone='11111111111')
        db.session.add(u)
        db.session.commit()

        assert u is not None


    def test_edit_article(self):
        """test check user"""
        u=User(username='john1', email='john@example.com', password='111111', phone='11111111111')
        db.session.add(u)
        db.session.commit()
        assert u is not None
        username1=u.username
        u.username='john'
        username2=u.username
        assert username1 !=username2

    def test_delete_article(self):
        """test delete user"""
        u=User(username='john1', email='john@example.com', password='111111', phone='11111111111')
        db.session.add(u)
        db.session.commit()
        assert u is not None
        db.session.delete(u)
        db.session.commit()
        user = User.query.filter(User.username ==
                                 'john1').first()
        assert user is  None





if __name__ == '__main__':
    unittest.main()