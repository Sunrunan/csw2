from app import db
from flask_login import login_user,UserMixin
from app import login
from werkzeug.security import generate_password_hash,check_password_hash
from hashlib import md5
import datetime
enrollment = db.Table('enrollment', db.Model.metadata,
    db.Column('article_id', db.Integer, db.ForeignKey('article.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)


@login.user_loader
def user_loader(id):
    return User.query.get(int(id))

class User(db.Model,UserMixin):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True,autoincrement = True)
    username = db.Column(db.String(15),index=True,nullable=False,unique=True)
    password = db.Column(db.String(25),index=True,nullable=False)
    date = db.Column(db.Date,default=datetime.datetime.now())
    phone = db.Column(db.String(11),index = True,nullable=False,unique=True)
    discription =db.Column(db.String(100),nullable=True,default='He is lazy, leaving nothing about himself.')
    avatar_hash = db.Column(db.String(32))
    email = db.Column(db.String(100),nullable=True)
    def login(self):
        login_user(self)
    def __init__(self,*args,**kwargs):
        phone = kwargs.get('phone')
        username = kwargs.get('username')
        password = kwargs.get('password')

        self.phone = phone
        self.username= username
        self.password = generate_password_hash(password)

    def check_password(self,raw_password):
        result = check_password_hash(self.password,raw_password)
        return result




class Article(db.Model):
    __tablename__ = 'article'

    id = db.Column(db.Integer, primary_key=True,autoincrement = True)
    title = db.Column(db.String(250), index=True, nullable=False)
    content = db.Column(db.String,index = True,nullable=False)
    date = db.Column(db.Date,default=datetime.datetime.now())
    author = db.relationship('User',backref=db.backref('articles'))
    tags = db.relationship('Tag',secondary=enrollment)
    authorid = db.Column(db.Integer,db.ForeignKey('user.id'))

    def _repr__(self):
        return self.id


class Comment(db.Model):
    __tablename__ = 'comment'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    content = db.Column(db.String, index=True, nullable=False)
    date = db.Column(db.Date,default=datetime.datetime.now())

    article = db.relationship('Article',backref = db.backref('comments'))
    articleid = db.Column(db.Integer, db.ForeignKey('article.id'))
    authorid = db.Column(db.Integer, db.ForeignKey('user.id'))
    author = db.relationship('User', backref=db.backref('comments'))
    def _repr__(self):
        return self.id


class Tag(db.Model):
    __tablename__ = 'tag'
    id = db.Column(db.Integer, primary_key=True,autoincrement = True)
    name = db.Column(db.String(50), index=True, nullable=False)
    articles = db.relationship('Article',secondary=enrollment)
    def _repr__(self):
        return self.id

class Record(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    content = db.Column(db.String, index=True, nullable=False)
    date = db.Column(db.Date, default=datetime.datetime.now())
    author = db.relationship('User', backref=db.backref('records'))
    authorid = db.Column(db.Integer, db.ForeignKey('user.id'))

    def _repr__(self):
        return self.id