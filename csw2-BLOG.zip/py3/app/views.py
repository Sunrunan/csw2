from flask import render_template, flash, redirect, session, url_for, request, g
from flask import Flask
from flask_admin.contrib.sqla import ModelView
import datetime
from app import app, db, admin
from .models import  User,Article,Comment,Tag,Record
from flask_login import LoginManager,login_required
from flask_login import logout_user

from sqlalchemy import and_,or_,not_
admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Article, db.session))
admin.add_view(ModelView(Comment, db.session))
admin.add_view(ModelView(Tag, db.session))
admin.add_view(ModelView(Record,db.session))


@app.route("/admin/")
@login_required
def admin():
    return render_template('admin.html',
                           title='admin',
                           )



#home page
@app.route("/")
def homepage():
    context = {
        'articles' : Article.query.order_by('-id')
    }
    return render_template('index.html',
                               title='homepage',
                               **context
                             )


#classify the blogs by 5 tags
@app.route("/Muscle gain/")
def Muscle_gain():
    tag = Tag.query.filter(Tag.name == 'Muscle gain').first()
    article = tag.articles

    context = {
        'articles': article
    }
    #record operation
    record = Record(content='see Muscle gain')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                               title='Muscle gain',
                               **context,
                                record=record
                             )


@app.route("/Fat loss/")
def Fat_loss():
    tag = Tag.query.filter(Tag.name=='Fat loss').first()
    article = tag.articles

    context = {
        'articles' : article
    }
    # record operation
    record = Record(content='see Fat loss')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                               title='Fat loss',
                               **context
                             )


@app.route("/Nutrition/")
def Nutrition():
    tag = Tag.query.filter(Tag.name=='Nutrition').first()
    article = tag.articles

    context = {
        'articles' : article
    }
    # record operation
    record = Record(content='see Nutrition')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                               title='Nutrition',
                               **context
                             )


@app.route("/Gym/")
def Gym():
    tag = Tag.query.filter(Tag.name=='Gym').first()
    article = tag.articles

    context = {
        'articles' : article
    }
    # record operation
    record = Record(content='see Gym')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                               title='Gym',
                               **context

                             )


@app.route("/Goodbody/")
def Goodbody():
    tag = Tag.query.filter(Tag.name=='Goodbody').first()
    article = tag.articles

    context = {
        'articles' : article
    }
    # record operation
    record = Record(content='see Goodbody')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                               title='Goodbody',
                               **context,
                             )



#login page
@app.route('/login/',methods=['GET','POST'])
def login():
    if request.method=='GET':
        return render_template('login.html',
                               title='log in',
                               )
    else:
        remember = request.form.get('remember')
        phone = request.form.get('phone')
        password = request.form.get('password')

        #all the blank should be filled
        if phone == ""  or password == "":
            flash("please fill all the field!")
            return render_template('login.html',
                                   title='log in',
                                   )
        # Login and validate the user.
        # user should be an instance of your `User` class
        user = User.query.filter(User.phone == phone).first()
        if user and user.check_password(password):
            session['user_id']=user.id
            user.date=datetime.datetime.now()
            if user.username=='admin':
                return redirect('/admin/')
            #remember me
            if remember:
                session.permanent=True
            # record operation
            record=Record(content='Login in')
            record.author=user
            user.records.append(record)
            db.session.add(record)
            db.session.commit()
            return redirect('/')
        else:
            flash('your phone number or password is wrong, please check and input again! ')
            return render_template('login.html',
                                   title='log in',
                                   )


#regiter page
@app.route('/register/', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
       return render_template('Registe.html',
                              title='registe',
                                   )
    else:
        phone =  request.form.get('phone')
        username = request.form.get('username')
        email = request.form.get('email')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')


    #phone number validation confirm, if exists then register fail
        user=User.query.filter(User.phone==phone).first()
        if user:
            flash('This phone number has been registed, please change your phone number!')
            return render_template('Registe.html',
                                   title='registe',
                                   )
        else:
            #password1 must be the same as password2
            if password1 != password2:
                flash("two passwords are not the same, please check and input again!")
                return render_template('Registe.html',
                                       title='registe',
                                       )
            #all the blank should be filled
            if phone=="" or username=="" or password1=="" or password2=="":
                flash("please fill all the field!")
                return render_template('Registe.html',
                                title='registe',
                                )
            else:
                user=User(phone=phone,username=username,password=password1,email=email)
                db.session.add(user)
                db.session.commit()
                # record operation
                record = Record(content='Registe')
                record.author = user
                user.records.append(record)
                db.session.add(record)
                db.session.commit()
                #if register succeed, redirect to login
                return redirect('/login/')


#logout page
@app.route('/logout/')
def logout():
    # record operation
    record = Record(content='Login in')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    logout_user()

    return redirect('/login/')



#post an article
@app.route('/post/', methods=['GET', 'POST'])
@login_required
def post():
    if request.method == 'GET':
        return render_template('post.html',
                              title='post blog',
                                   )
    else:
        #get the value from html by request
        title = request.form.get('title')
        content = request.form.get('content')
        content = content.replace('\n',  '<br/>')
        tag1 = request.form.get('tag1')
        tag2 = request.form.get('tag2')
        tag3 = request.form.get('tag3')
        tag4 = request.form.get('tag4')
        tag5 = request.form.get('tag5')
        #create an article
        article = Article(title=title,content=content)
        db.session.add(article)
        db.session.commit()
        #build relasion
        article.author = g.user
        g.user.articles.append(article)
        if tag1:
            article.tags.append(Tag.query.filter(Tag.name=='Muscle gain').first())
        if tag2:
            article.tags.append(Tag.query.filter(Tag.name == 'Fat loss').first())
        if tag3:
            article.tags.append(Tag.query.filter(Tag.name=='Nutrition').first())
        if tag4:
            article.tags.append(Tag.query.filter(Tag.name=='Gym').first())
        if tag5:
            article.tags.append(Tag.query.filter(Tag.name=='Goodbody').first())
        #record operation
        record = Record(content='Post a blog')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect('/')


#display detail info of an article
@app.route('/detail/<article_id>/')
def detail(article_id):

    article=  Article.query.filter(Article.id==article_id).first()
    #record operation
    record = Record(content='Read a blog')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('detail.html',title=article.title,article=article,user=g.user)


#personal page
@app.route('/personal/<user_id>/')
def personal(user_id):
    user = User.query.filter(User.id==user_id).first()
    articles = user.articles
    # record operation
    if user==g.user:
        record = Record(content='enter his personal page')
    else:
        record = Record(content='enter others personal page')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    if g.user.username=='admin':
        return redirect('/admin')
    return render_template('Personal.html',
                           title=user.username,
                           articles=articles,
                           username=user.username,
                           date=user.date,
                           discription=user.discription,
                           email=user.email,
                           id=user.id,
                           user=g.user
                           )


#add_comment page
@app.route('/add_comment/',methods=['GET','POST'])
@login_required
def add_comment():
    #get data from html by request
    content = request.form.get('comment')
    content = content.replace('\n', '<br/>')
    #create new comment
    comment = Comment(content=content)
    db.session.add(comment)
    db.session.commit()
    #build relasion
    article_id=request.form.get('article_id')
    article=Article.query.filter(Article.id==article_id).first()
    comment.author = g.user
    comment.article = article
    article.comments.append(comment)
    g.user.comments.append(comment)
    #record operation
    record = Record(content='Add a comment')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return redirect(url_for('detail',article_id=article_id))


#search page
@app.route('/search/',methods=['GET','POST'])
def search():
    q=request.form.get('q')
    articles=Article.query.filter(or_(Article.title.contains(q),Article.content.contains(q))).order_by('-date')
    #record operation
    record = Record(content='search')
    record.author = g.user
    g.user.records.append(record)
    db.session.add(record)
    db.session.commit()
    return render_template('index.html',
                           title='homepage',
                            articles=articles

                           )

#edit article
@app.route('/edit/<article_id>/',methods=['GET','POST'])
def edit(article_id):
    article=Article.query.filter(Article.id==article_id).first()
    if request.method == 'GET':
        return render_template('edit.html',
                               title='edit',
                               article=article
                               )
    else:
        #get the data from html by request
        title = request.form.get('title')
        content = request.form.get('content')
        content = content.replace('\n', '<br/>')
        #change the value of the attribute of article
        article.content=content
        article.title=title
        article.date=datetime.datetime.now()
        db.session.commit()
        #record operation
        record = Record(content='edit his blog')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('personal',user_id=article.author.id))


#edit comment
@app.route('/edit3/<comment_id>/',methods=['GET','POST'])
def edit3(comment_id):
    comment=Comment.query.filter(Comment.id==comment_id).first()
    if request.method == 'GET':
        return render_template('edit3.html',
                               title='edit',
                               comment=comment
                               )
    else:
        #get data from html by request
        content = request.form.get('content')
        content = content.replace('\n', '<br/>')
        #change the value of attribute of comment
        comment.content=content
        comment.date=datetime.datetime.now()
        db.session.commit()
        #record the operation
        record = Record(content='edit his comment')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('detail',article_id=comment.article.id))


#edit personal info
@app.route('/edit2/<user_id>/',methods=['GET','POST'])
def edit2(user_id):
    user = User.query.filter(User.id == user_id).first()
    if request.method == 'GET':
        return render_template('edit2.html',
                               title='edit',
                               )
    else:
        #get the data from html by request
        discription=request.form.get('discription')
        email= request.form.get('email')
        #change the value of attribute of user
        user.discription=discription
        user.email=email
        db.session.commit()
        #record the operation
        record = Record(content='edit his personal info')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('personal', user_id=user_id))


#delete article
@app.route('/delete/<article_id>/', methods=['GET'])
def delete(article_id):
        article = Article.query.filter(Article.id == article_id).first()
        user_id=article.author.id
        #delete article
        db.session.delete(article)
        db.session.commit()
        #record the operation
        record = Record(content='delete his blog')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('personal', user_id=user_id))


#delete comment
@app.route('/delete2/<comment_id>/', methods=['GET'])
def delete2(comment_id):
        comment = Comment.query.filter(Comment.id == comment_id).first()
        article_id=comment.article.id
        #delete comment
        db.session.delete(comment)
        db.session.commit()
        #record the operation
        record = Record(content='delete his comment')
        record.author = g.user
        g.user.records.append(record)
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('detail', article_id=article_id))


#use g class to modify the code
@app.before_request
def my_before_request():
    user_id = session.get('user_id')
    if user_id:
        user = User.query.filter(User.id==user_id).first()
        if user:
            g.user=user


#user for login status record
@app.context_processor
def my_context_processor():
    if hasattr(g,'user'):
        return {'user':g.user}
    return {}


